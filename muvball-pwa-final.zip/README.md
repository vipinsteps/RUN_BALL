# MuvBall PWA - Ceratizit Ball Nose Calculator

This is a Progressive Web App for the MuvBall cutting tool calculator.

## Hosting Instructions:
1. Upload all files from this ZIP to a GitHub repo (e.g., MuvBall).
2. Enable GitHub Pages: Settings > Pages > Source: main, folder: root.
3. Your app will be live at:
   https://yourusername.github.io/MuvBall/

Users can 'Add to Home Screen' on mobile or install on desktop.

Files included:
- index.html
- manifest.json
- service-worker.js
- logo192.png
